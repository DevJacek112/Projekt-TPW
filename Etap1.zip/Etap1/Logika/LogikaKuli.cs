﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dane;


namespace Logika
{
    internal class LogikaKuli
    {
        Kula kula = new Kula(30, 30, 0, 0);
        public void spawn()
        {

        }
    }
}
