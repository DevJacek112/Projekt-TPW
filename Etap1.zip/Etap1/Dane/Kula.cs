﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dane
{
    public class Kula
    {
        private int height;
        private int width;
        private int x;
        private int y;

        public Kula(int height, int width, int x, int y)
        {
            this.height = height;
            this.width = width;
            this.x = x;
            this.y = y;
        }
    }
}
